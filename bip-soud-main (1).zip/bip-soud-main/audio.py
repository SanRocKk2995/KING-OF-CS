import numpy as np
import sounddevice as sd

def Beep(frequency=500, duration=0.25, volume=0.15):
    """
    Beep nhẹ kiểu 'giọt nước' mềm mại
    frequency: tần số Hz (thấp để êm)
    duration: thời gian (giây)
    volume: âm lượng (0.0 -> 1.0)
    """
    samplerate = 44100
    t = np.linspace(0, duration, int(samplerate * duration), False)

    # sóng sin + tắt dần
    wave = np.sin(2 * np.pi * frequency * t) * np.exp(-6 * t) * volume

    sd.play(wave, samplerate)
    sd.wait()
