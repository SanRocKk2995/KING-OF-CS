# offsets.py
import re
import requests

OFFSETS_URL = "https://raw.githubusercontent.com/a2x/cs2-dumper/main/output/offsets.cs"
CLIENTDLL_URL = "https://raw.githubusercontent.com/a2x/cs2-dumper/main/output/client_dll.cs"

class Client:
    def __init__(self):
        self.offsets = self._parse_offsets(OFFSETS_URL)
        self.clientdll = self._parse_clientdll(CLIENTDLL_URL)

    def _parse_offsets(self, url):
        text = requests.get(url, timeout=5).text
        # Tìm tất cả dòng: public const nint <name> = 0x1234;
        pattern = re.compile(r"public const nint (\w+) = (0x[0-9A-Fa-f]+);")
        return {name: int(val, 16) for name, val in pattern.findall(text)}

    def _parse_clientdll(self, url):
        text = requests.get(url, timeout=5).text
        clientdll = {}
        current_class = None

        for line in text.splitlines():
            line = line.strip()

            # phát hiện class
            m_class = re.match(r"public static class (\w+)", line)
            if m_class:
                current_class = m_class.group(1)
                clientdll[current_class] = {}
                continue

            # phát hiện field
            m_field = re.match(r"public const nint (\w+) = (0x[0-9A-Fa-f]+);", line)
            if m_field and current_class:
                field, val = m_field.groups()
                clientdll[current_class][field] = int(val, 16)

        return clientdll

    def offset(self, name):
        if name not in self.offsets:
            raise KeyError(f"Offset {name} not found")
        return self.offsets[name]

    def get(self, class_name, field_name):
        try:
            return self.clientdll[class_name][field_name]
        except KeyError:
            raise KeyError(f"Unable to get {class_name}.{field_name}")

# Khởi tạo client sẵn khi import
client = Client()
